# @datum-sdk/plugins

Optional tree-shakeable extensions for [`@datum-sdk/engine`](../engine). Provides stats collection, visual debugging, and a full-featured 3D scene editor (POI, camera routes, collisions) with undo/redo history.

## Installation

See [registry setup and installation instructions](../../README.md#using-the-sdk) in the root README.

```bash
npm install @datum-sdk/plugins
```

### Peer Dependencies

- `@datum-sdk/engine` ^0.6.1

`three` and `@sparkjsdev/spark` are provided transitively by `@datum-sdk/engine`.

## Exports

```typescript
import {
    CollisionStyleManager,
    DatumEditor,
    DatumEngineStats,
    DebugOverlay,
    getWaypointFlightType,
    HistoryManager,
    // Camera route waypoint utilities
    WAYPOINT_FLIGHT_TYPES,
    // Types
    type HistoryState,
    type HotkeyHint,
    type WaypointFlightType,
} from '@datum-sdk/plugins';
```

### Waypoint Flight Types

Utilities for working with camera route waypoints:

- **`WAYPOINT_FLIGHT_TYPES`** — `['orbit', 'linear', 'rotate'] as const`. The set of possible flight types for camera route waypoints.
- **`WaypointFlightType`** — `'orbit' | 'linear' | 'rotate'`. Derived from `WAYPOINT_FLIGHT_TYPES`.
- **`getWaypointFlightType(waypoint: Waypoint): WaypointFlightType`** — Determines the flight type of a given waypoint based on its `orbit` and `target` fields.

### Types

- **`HistoryState`** — Current state of the `HistoryManager`: `{ canUndo: boolean; canRedo: boolean; undoLabel?: string; redoLabel?: string }`.
- **`HotkeyHint`** — Describes an active hotkey binding exposed by an editor plugin: `{ key: string; label: string }`.

---

## CollisionStyleManager

Standalone Blender-style overlay for collision meshes. Shows semi-transparent grey faces with edge lines. Can be used without the collision editor for debug visualization.

```typescript
import { DatumEngine } from '@datum-sdk/engine';
import { CollisionStyleManager } from '@datum-sdk/plugins';

const engine = new DatumEngine({ container: document.getElementById('viewer')! });
const styles = new CollisionStyleManager(engine);

// Show overlays on all colliders
styles.showAll();

// Hide overlays
styles.hideAll();

// Clean up
styles.dispose();
```

---

## DatumEngineStats

Statistics collector. Hooks into the engine render loop and emits periodic stats updates.

```typescript
import { DatumEngine } from '@datum-sdk/engine';
import { DatumEngineStats } from '@datum-sdk/plugins';

const engine = new DatumEngine({ container: document.getElementById('viewer')! });
const stats = new DatumEngineStats(engine, {
    fpsUpdateInterval: 1000, // Update FPS every second (default)
});

// Note: with idle render throttling enabled, `fps` reflects effective
// render cadence and automatically drops to 0 when rendering is paused.

// Subscribe to stats updates
stats.on('stats', (s) => console.log('FPS:', s.fps));

// Get current stats
const currentStats = stats.getStats();

// Clean up
stats.dispose();
```

### RenderStats Interface

```typescript
interface RenderStats {
    fps: number;
    frameTime: number;
    activeSplats: number;
    loadedSplats: number;
    totalSplats: number;
    isStreaming: boolean;
    loadedBytes: number;
    totalBytes: number;
    loadedChunks: number;
    totalChunks: number;
    memoryMB?: number; // Chrome only
    textures: number;
    geometries: number;
    drawCalls: number;
    lastLoad: LastLoadStats;
    collisionSolveMs: number; // 0 when disabled
}

interface LastLoadStats {
    previewBytes: number | null;
    previewDownloadMs: number | null;
    sceneBytes: number | null;
    sceneDownloadMs: number | null;
    processingMs: number | null;
    streaming: boolean;
    totalSceneBytes: number | null;
    totalSceneSplats: number | null;
}
```

---

## DebugOverlay

Visual debugging plugin. Renders a grid, axes helper, and orbit target marker on top of the scene.

```typescript
import { DatumEngine } from '@datum-sdk/engine';
import { DebugOverlay } from '@datum-sdk/plugins';

const engine = new DatumEngine({ container: document.getElementById('viewer')! });
const debug = new DebugOverlay(engine, {
    gridSize: 100, // meters (default: 100)
    gridDivisions: 100, // (default: 100)
    axisLength: 50, // meters (default: 50)
    showGrid: true,
    showAxes: true,
    showOrbitTarget: true,
});

// Active from creation; call dispose() when done
debug.dispose();
```

---

## DatumEditor (Editor Facade)

Unified editor facade that manages POI, camera route, collision, and scene transform editing through a single API with undo/redo history and unidirectional data flow. The facade manages plugin lifecycle internally — the host only calls `setType()` to switch modes.

```typescript
import { DatumEngine } from '@datum-sdk/engine';
import { DatumEditor, type EditorType } from '@datum-sdk/plugins';

const engine = new DatumEngine({ container: document.getElementById('viewer')! });
const editor = new DatumEditor(engine);

// Subscribe to list-level change events
editor.on('poi:change', (pois) => console.log('POIs changed:', pois.length));
// Switch editor mode
editor.setType('poi');

// All mutations go through accessor methods
editor.poi.create([1, 2, 3]);
editor.poi.update('poi-1', { label: 'Entry' });
editor.poi.select(myPoi);

// Route editing
editor.setType('camera-route');
editor.route.createRoute({ waypoints: [{ target: [0, 1, 5] }] });
editor.route.selectWaypoint(0);

// Collision editing
editor.setType('collision');
editor.collision.create({ shape: 'box' });
editor.collision.update('box-1', { role: 'containment' });

// Clean up
editor.dispose();
```

### Construction

```typescript
const editor = new DatumEditor(engine);
```

The constructor accepts a `DatumEngine` instance. It internally creates a shared `HistoryManager` with keyboard shortcuts (`Cmd+Z` / `Ctrl+Z`) bound to `window`.

### Mode Management

```typescript
editor.setType('poi'); // activate POI editor
editor.setType('camera-route'); // activate route editor
editor.setType('collision'); // activate collision editor
editor.setType('scene-transform'); // activate scene transform editor
editor.setType(null); // deactivate all editors
```

`setType()` disposes the previous plugin and creates a new one. Mode switches are recorded as `UndoableAction` entries in the shared history.

### API Accessors

Sub-APIs are accessed via property getters that return cached API objects. When the corresponding mode is not active, getters return a no-op fallback that silently ignores all calls.

```typescript
editor.poi: PoiApi
editor.collision: CollisionApi
editor.route: RouteApi
```

### DatumEditor Events (`DatumEditorEventMap`)

| Event               | Payload                                         | Description                                       |
| ------------------- | ----------------------------------------------- | ------------------------------------------------- |
| `type:update`       | `EditorType`                                    | Editor mode switched                              |
| `hotkey:update`     | `HotkeyHint[]`                                  | Available hotkey hints changed                    |
| `poi:select`        | `Poi`                                           | POI selected                                      |
| `poi:deselect`      | `Poi`                                           | POI deselected                                    |
| `poi:change`        | `Poi[]`                                         | POI list changed (create/update/delete)           |
| `collider:select`   | `ColliderConfig`                                | Collider selected                                 |
| `collider:deselect` | `ColliderConfig`                                | Collider deselected                               |
| `collider:change`   | `ColliderConfig[]`                              | Collider list changed (create/update/delete)      |
| `route:select`      | `CameraRoute`                                   | Active route changed                              |
| `route:change`      | `CameraRoute[]`                                 | Route list changed (create/update/delete)         |
| `waypoint:select`   | `{ waypoint: Waypoint \| null; index: number }` | Waypoint selected                                 |
| `waypoint:change`   | `{ waypoints: Waypoint[] }`                     | Waypoint list changed (add/remove/update/reorder) |
| `scene:update`      | `{ scene: Scene }`                              | Scene transform changed (scene-transform editor)  |

### POI Methods (`editor.poi`)

| Method              | History | Description                                  |
| ------------------- | ------- | -------------------------------------------- |
| `select(poi)`       | No      | Select a POI (attaches gizmo)                |
| `clearSelection()`  | No      | Deselect the current POI                     |
| `create(position)`  | Plugin  | Create a new POI at position                 |
| `update(id, patch)` | Plugin  | Patch POI fields (mergeable for rapid input) |
| `remove(poi)`       | Plugin  | Delete a POI                                 |

### Collision Methods (`editor.collision`)

| Method              | History | Description                                      |
| ------------------- | ------- | ------------------------------------------------ |
| `select(collider)`  | No      | Select a collider by config                      |
| `create(config)`    | Plugin  | Add a collider from a `ColliderConfig`           |
| `update(id, patch)` | Plugin  | Patch collider fields (mergeable for transforms) |
| `remove(id)`        | Plugin  | Remove a collider by ID                          |

### Route Methods (`editor.route`)

| Method                              | History | Description                                          |
| ----------------------------------- | ------- | ---------------------------------------------------- |
| `selectRoute(id)`                   | No      | Set the active route                                 |
| `deselectRoute()`                   | No      | Clear route selection                                |
| `createRoute(params)`               | Facade  | Create a route (params: waypoints + optional fields) |
| `deleteRoute(id)`                   | Facade  | Delete a route                                       |
| `updateRoute(settings)`             | Plugin  | Update route settings (loop, mode, speed)            |
| `selectWaypoint(index)`             | No      | Select a waypoint by index or `'next'`/`'prev'`      |
| `deselectWaypoint()`                | No      | Clear waypoint selection                             |
| `createWaypoint(waypoint?, index?)` | Plugin  | Add a waypoint (optional position in list)           |
| `deleteWaypoint(index)`             | Plugin  | Remove a waypoint by index                           |
| `updateWaypoint(index, patch)`      | Plugin  | Update waypoint fields                               |
| `moveWaypoint(from, to)`            | Plugin  | Reorder a waypoint                                   |
| `setWaypointFlightType(type)`       | Plugin  | Change flight type of the selected waypoint          |
| `addLookAtPoint(index)`             | Plugin  | Add a lookAt point to a waypoint                     |
| `setSelectedWaypointFromCamera()`   | Plugin  | Set selected waypoint's camera from current view     |
| `setShowLookAtLines(show)`          | No      | Toggle lookAt visualization                          |
| `startClickPlacement()`             | No      | Start interactive waypoint placement mode            |

The "History" column indicates where undo/redo actions are recorded: **Facade** means the facade pushes its own `UndoableAction` (route CRUD); **Plugin** means the underlying editor plugin records history internally; **No** means the operation is not undoable (selection, navigation, playback).

> **Playback** is controlled via `DatumEngine` directly: `startCameraRoute(routeId)`, `pauseCameraRoute()`, `resumeCameraRoute()`, `stopCameraRoute()`.

### Hotkey Hints

The editor exposes context-sensitive hotkey hints via the `hotkey:update` event:

```typescript
interface HotkeyHint {
    action: string; // e.g. 'deselect', 'create'
    label: string; // e.g. "Deselect", "Create POI"
    keyLabel: string; // e.g. "Esc", "⌘", "Ctrl"
    trigger: 'press' | 'hold';
    active: boolean; // whether a hold binding is currently active
    group?: string;
}
```

---

## Example: Engine + Plugins

```typescript
import { DatumEngine, type CameraState } from '@datum-sdk/engine';
import { DatumEngineStats, DebugOverlay } from '@datum-sdk/plugins';

const initialCamera: CameraState = {
    position: [5, 2, 5],
    quaternion: [0, 0.3, 0, 0.95],
    fov: 60,
};

const engine = new DatumEngine({
    container: document.getElementById('viewer')!,
    controlsMode: 'orbit',
    environment: {
        background: [0.1, 0.1, 0.18, 1],
    },
});

const scene = await fetch('/api/scenes/123').then((res) => res.json());
engine.loadScene(scene);
engine.setCameraState(initialCamera, { mode: 'reset' });

// Enable debug overlay (active from creation)
const debug = new DebugOverlay(engine);

// Collect and log stats
const stats = new DatumEngineStats(engine);
stats.on('stats', (s) => console.log(`FPS: ${s.fps}, Splats: ${s.totalSplats}`));

// Clean up when done
function cleanup() {
    stats.dispose();
    debug.dispose();
    engine.destroy();
}
```

## Styles

Some plugins ship CSS (e.g. joystick theming). Import styles alongside the engine CSS:

```typescript
import '@datum-sdk/engine/index.min.css';
import '@datum-sdk/plugins/index.min.css';
```

## License

MIT
