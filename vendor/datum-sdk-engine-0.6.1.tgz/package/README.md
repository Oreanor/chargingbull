# @datum-sdk/engine

A web library for viewing and interacting with 3D Gaussian Splatting scenes using Three.js and Spark.

## Installation

See [registry setup and installation instructions](../../README.md#using-the-sdk) in the root README.

```bash
npm install @datum-sdk/engine "three@>=0.180.0" @sparkjsdev/spark@npm:@datum-sdk/spark-fork
```

## Quick Start

```typescript
import { DatumEngine } from '@datum-sdk/engine';

// Create viewer with minimal options
const engine = new DatumEngine({
    container: document.getElementById('viewer')!,
});

// Listen for events
engine.on('scene:loaded', ({ splatsCount }) => {
    console.log(`Model loaded with ${splatsCount} splats!`);
});

engine.on('scene:error', ({ error }) => {
    console.error('Failed to load:', error);
});

// Load a scene from your API
const scene = await fetch('/api/scenes/123').then((res) => res.json());
engine.loadScene(scene);
```

### Loading a local file

If you have a `.sog` or `.ply` file and want to load it directly without a backend:

```typescript
engine.loadScene({
    version: '0.1',
    id: 'my-scene',
    createdAt: new Date().toISOString(),
    models: [
        {
            id: 'model-1',
            file: {
                id: 'file-1',
                fileUrl: '/scenes/my-scene.sog',
                sizeBytes: 0,
                filename: 'my-scene.sog',
                uploadedAt: new Date().toISOString(),
            },
            isVisible: true,
            createdAt: new Date().toISOString(),
        },
    ],
    settings: {
        camera: {
            position: [5, 3, 5],
            quaternion: [0, 0, 0, 1],
            fov: 60,
        },
    },
});
```

## Features

- **Gaussian Splatting rendering** — powered by [Spark](https://sparkjs.dev/) ([fork](https://gitlab.thedatum.one/datum/datum-sdk-spark-fork))
- **FPS and Orbit controls** — switch between first-person and orbit camera modes
- **Debug mode** — grid, axes, and orbit target visualization
- **Full Three.js access** — customize scene, camera, and renderer
- **POI editor mode** — edit POI positions via TransformControls
- **Waypoint editor mode** — visual editing of camera route waypoints with 3D spheres, path lines, and TransformControls

## World Units Policy

The engine core is unitless.

However, Datum SDK defines the following convention:

- 1 world unit = 1 meter
- Y-up coordinate system
- Forward direction = -Z
- All distances, radii, covariances and LOD thresholds are specified in meters

---

## Architecture

This section describes the key architectural principles for developers who want to extend or contribute to the package.

### Directory Structure

```
src/
├── datum-engine.ts          # Main public class (Facade)
├── index.ts                 # Public API barrel file
├── types/                   # TypeScript interfaces (barrel re-export)
│   ├── index.ts             # Main types barrel
│   ├── camera.ts            # Camera controller types
│   ├── collision.ts         # Collision types
│   └── appearance.ts        # Scene appearance types
├── lib/                     # Reusable utilities
│   ├── event-emitter.ts     # Base class for event handling
│   ├── log.ts               # Logging utility
│   ├── utils.ts             # Internal math helpers
│   ├── types.ts             # Shared types (ObjectTransform, OrbitSpherical, etc.)
│   ├── easing.ts            # Easing presets and cubic-bezier
│   └── publicHelpers.ts     # Public helpers namespace
├── modules/                 # Internal modules (not exported)
│   ├── camera-controller/   # Camera, controls, routes
│   ├── collision-manager/   # Collider CRUD, collision solver
│   ├── poi-manager/
│   ├── scene-appearance/
│   └── environment-manager/
```

### Key Architectural Principles

#### 1. Facade Pattern

`DatumEngine` acts as a **Facade** that hides the complexity of multiple subsystems:

- Three.js Scene/Renderer
- Spark rendering engine
- Camera controls (OrbitControls, SparkControls)
- Model loading (SplatLoader)

```typescript
// Simple API for common use cases
const engine = new DatumEngine({ container: element });

// But full access to internals when needed
const camera = engine.getCamera();
const scene = engine.getScene();
const renderer = engine.getRenderer();
```

This balances ease of use for simple cases with flexibility for power users.

#### 2. Composition over Inheritance

`DatumEngine` uses composition to assemble functionality:

- **Extends** `EventEmitter` (inheritance for cross-cutting concern)
- **Composes** other components:
    - `CameraController` — delegated module for camera/controls management
    - `SparkRenderer` — external rendering engine
    - `THREE.Scene`, `THREE.WebGLRenderer` — Three.js objects

Each composed component has a single responsibility, making the code easier to test and maintain.

#### 3. Plugin Architecture (Tree-Shakeable Extensions)

Optional functionality lives in a separate package — [`@datum-sdk/plugins`](../plugins) — and is fully tree-shakeable. See the [plugins README](../plugins/README.md) for the full API (stats, debug overlay, editor).

Plugins connect to the engine via **render loop callbacks**:

```typescript
// Inside DatumEngine
private beforeRenderCallbacks: Array<() => void> = [];
private afterRenderCallbacks: Array<{ callback: () => void; order: number }> = [];

// Plugins hook into the render loop
public addBeforeRenderCallback(callback: () => void): void;
public addAfterRenderCallback(callback: () => void, order?: number): void;
```

After-render callbacks are executed in ascending `order` — lower values draw first (behind), higher values draw on top. Overlay order constants are available from the internal entry point:

| Constant               | Value | Import from                  | Used by                                             |
| ---------------------- | ----- | ---------------------------- | --------------------------------------------------- |
| `OVERLAY_ORDER_DEBUG`  | `0`   | `@datum-sdk/engine/internal` | `DebugOverlay` (grid, axes, markers)                |
| `OVERLAY_ORDER_EDITOR` | `100` | `@datum-sdk/engine/internal` | `EditorPoi`, `EditorCameraRoute`, `EditorCollision` |

**Creating Custom Plugins:**

```typescript
import { OVERLAY_ORDER_EDITOR } from '@datum-sdk/engine/internal';

class MyPlugin {
    private engine: DatumEngine;
    private callback: () => void;

    constructor(engine: DatumEngine) {
        this.engine = engine;
        this.callback = this.onRender.bind(this);
        this.engine.addAfterRenderCallback(this.callback, OVERLAY_ORDER_EDITOR);
    }

    private onRender(): void {
        // Your per-frame logic here
    }

    dispose(): void {
        this.engine.removeAfterRenderCallback(this.callback);
    }
}
```

#### 4. Event-Driven Communication

The `EventEmitter` base class provides type-safe event handling:

```typescript
// Type-safe event map (combines scene, camera, POI, route, and camera controller events)
type DatumEngineEventMap = SceneEventMap &
    CameraEventMap &
    PoiEventMap &
    CameraRouteEventMap &
    CameraControllerEventMap;

// Usage
engine.on('scene:loaded', ({ splatsCount }) => {
    // TypeScript knows splatsCount is a number
});

engine.on('route:waypoint-reached', ({ routeId, waypointIndex, poiId }) => {
    // TypeScript knows routeId is a string, waypointIndex is a number, poiId is string | undefined
});
```

Key features:

- `on()` — subscribe to events
- `once()` — subscribe once (auto-removes after first emission)
- `off()` — unsubscribe from events
- `emit()` — protected, only the class can emit its own events
- Error handling in listeners (errors are caught and logged)

#### 5. Strict Lifecycle Management

All components follow a strict **constructor/dispose** lifecycle:

```typescript
// Construction: create resources, start loops
const engine = new DatumEngine({ ... });

// Operation: render loop, event handling
engine.on('scene:loaded', ...);

// Destruction: clean up everything
engine.destroy();
```

The `isDestroyed` flag guards against zombie operations:

```typescript
private renderLoop = (): void => {
    if (this.isDestroyed) return;  // Guard against use-after-destroy
    // ... render logic
};
```

**Destruction sequence:**

1. Set `isDestroyed = true`
2. Cancel animation frame
3. Remove DOM event listeners
4. Dispose scene resources (meshes, materials)
5. Remove DOM elements
6. Clear callback arrays
7. Remove all event listeners

#### 6. Internal vs Public Modules

- **`lib/`** — Reusable utilities (EventEmitter, logging)
- **`modules/`** — Internal implementation details (marked `@internal`)
- **`plugins/`** — Public optional extensions (exported via index.ts)

Internal modules are not exported and should not be used directly:

```typescript
/**
 * Camera controller module for DatumEngine.
 * @internal
 */
export class CameraController { ... }
```

---

## API Reference

### Constructor

```typescript
new DatumEngine(options: DatumEngineOptions, scene?: Scene, sceneOverrides?: Partial<Scene>)
```

- `options` — engine configuration (container, controls, render settings, etc.)
- `scene` — optional initial scene to load on creation
- `sceneOverrides` — optional partial scene fields to deep-merge into the initial scene (same as `loadScene` overrides)

### Constructor Options

```typescript
interface DatumEngineOptions {
    /** HTML container element (defaults to document.body) */
    container?: HTMLElement;
    /** Default controls mode: 'fps' or 'orbit' (defaults to 'fps', scene mode takes priority) */
    controlsMode?: ControlsMode;
    /** Default camera controller settings (scene settings take priority) */
    cameraController?: CameraControllerSettings;
    /** Default render settings (scene's render settings take priority) */
    renderSettings?: RenderSettings;
    /** Per-tier render setting overrides (device-dependent fields only). */
    renderSettingsByTier?: TierRenderSettingsMap;
    /** Force a specific device tier, bypassing auto-detection. */
    deviceTier?: DeviceTier;
    /** Default environment settings (scene's environment takes priority) */
    environment?: EnvironmentSettings;
}
```

The engine auto-detects a device tier (`'high'` or `'low'`) at construction time using hardware heuristics (core count, memory, mobile UA). Pass `deviceTier` to bypass detection and force a specific tier. Settings are merged lowest-to-highest priority:

```
DEFAULT_RENDER_SETTINGS → built-in tier preset → renderSettings → renderSettingsByTier[tier] → scene renderSettings → scene renderSettingsByTier[tier]
```

The built-in tier presets are exported as `HIGH_TIER_RENDER_SETTINGS` and `LOW_TIER_RENDER_SETTINGS` for use in UIs and custom tier logic. `renderSettingsByTier` overrides `renderSettings` for device-dependent fields, letting you set a baseline via `renderSettings` and refine per tier:

```typescript
const engine = new DatumEngine({
    container: document.getElementById('viewer')!,
    renderSettings: { maxPixelRadius: 256 },
    renderSettingsByTier: {
        low: { maxPixelRadius: 128, maxStdDev: 2 },
    },
});
```

The tier can also be forced per scene via `SceneSettings.deviceTier`. When set, `loadScene()` switches the active tier before applying the render settings merge chain:

```typescript
engine.loadScene({
    ...scene,
    settings: { ...scene.settings, deviceTier: 'low' },
});
```

The available tier values are exported as a `DEVICE_TIERS` array (`['high', 'low']`) for building UIs (dropdowns, toggles) without hardcoding strings.

### Scene

The `Scene` object describes a 3D scene loaded via `loadScene()`.

```typescript
interface Scene {
    version: '0.1'; // Scene format version
    id: string; // Unique scene identifier
    createdAt: string; // ISO timestamp
    updatedAt?: string; // ISO timestamp
    models: Model[] | null; // 3D models (first visible model is loaded)
    settings?: SceneSettings | null; // Rendering and transform settings
    annotations?: SceneAnnotations | null; // Metadata annotations (POIs, etc.)
}

interface Model {
    id: string; // Model identifier
    file: FileDto; // Model file data
    isVisible: boolean; // Whether the model is visible
    settings?: Record<string, unknown>; // Model-specific settings
    createdAt: string; // ISO timestamp
    updatedAt?: string; // ISO timestamp
}

interface FileDto {
    id: string; // Unique file identifier
    fileUrl: string; // Direct URL to download the file
    sizeBytes: number; // File size in bytes
    filename: string; // Original filename
    uploadedAt: string; // ISO timestamp
    contentMetadata?: {
        // Content metadata (optional)
        type?: string; // File type
        splatCount?: number; // Number of splats in the file
    };
}
```

The engine loads the first model with `isVisible: true` from the `models` array.

#### SceneSettings

```typescript
interface SceneSettings {
    transform?: ObjectTransform; // Scene position, quaternion, and scale
    camera?: CameraState; // Initial camera position/orientation
    cameraMode?: ControlsMode; // 'fps' | 'orbit' (applied on loadScene)
    cameraController?: CameraControllerSettings; // Camera controller overrides
    renderSettings?: RenderSettings; // Scene-level render settings
    renderSettingsByTier?: TierRenderSettingsMap; // Per-tier render overrides (highest priority)
    deviceTier?: DeviceTier; // Force tier for this scene
    environment?: EnvironmentSettings; // Environment/background settings
    appearance?: SceneAppearanceConfig; // Reveal/unreveal, preview model
    cameraRoutes?: CameraRoute[]; // Camera animation routes
    collisions?: SceneCollisionConfig; // Collision meshes and camera collision
    streaming?: StreamingSettings; // Streaming/LOD endpoint
}

interface StreamingSettings {
    url: string; // Streaming endpoint URL
    pagedExtSplats?: boolean; // Enable paged extension splats
}
```

### Scene Appearance

```typescript
/** Radial wave effect — splats appear outward from an origin point */
interface SpreadRevealEffect {
    type: 'spread';
    /** Effect radius in meters (defaults to bbox-based calculation) */
    radius?: number;
    /** Effect origin point in meters (defaults to [0, 0, 0]) */
    origin?: 'camera' | number[];
    /** Duration in seconds (defaults to 2.0) */
    duration?: number;
    /** Easing function (defaults to 'easeInOut') */
    easing?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut';
}

/** Uniform fade effect — all splats appear/disappear simultaneously */
interface FadeRevealEffect {
    type: 'fade';
    /** Duration in seconds (defaults to 2.0) */
    duration?: number;
    /** Easing function (defaults to 'easeInOut') */
    easing?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut';
}

type RevealEffect = SpreadRevealEffect | FadeRevealEffect;

interface SceneAppearanceConfig {
    /** Reveal effect (scene appearing). If only reveal is set, unreveal mirrors it. */
    reveal?: RevealEffect;
    /** Unreveal effect (scene hiding). If only unreveal is set, reveal mirrors it. */
    unreveal?: RevealEffect;
    /** Default transition mode: 'auto' starts reveal immediately, 'manual' stays on preview (default: 'auto'). Overridden via loadScene overrides */
    transitionMode?: SceneTransitionMode;
    /** Release splat resources when transitioning to preview (default: false) */
    releaseResources?: boolean;
    /** URL to preview GLB model */
    previewModelUrl?: string;
    /** Transform for preview model (applied after scene transform) */
    previewTransform?: ObjectTransform;
    /** Preview model color as RGBA array, alpha = blend intensity */
    previewColor?: number[];
    /** Preview model color blending mode (defaults to 'replace') */
    previewColorBlendMode?: BlendMode;
    /** Preview model opacity (defaults to 1.0) */
    previewOpacity?: number;
    /** Preview model point size multiplier (defaults to 1.0) */
    previewSizeMultiplier?: number;
    /** Point appearance animation settings */
    previewAppearance?: {
        /** Disable point appearance animation (defaults to false) */
        disabled?: boolean;
        /** Duration in seconds (defaults to 1.0) */
        duration?: number;
        /** Points inside this radius appear first (defaults to 0.4) */
        highPriorityRadius?: number;
    };
    /** Preview animation settings */
    previewAnimation?: {
        type: 'waves';
        /** Wave width factor (defaults to 3.0) */
        amplitude?: number;
        /** Number of simultaneous waves (defaults to 1.0) */
        period?: number;
        /** Wave speed multiplier (defaults to 1.0) */
        speed?: number;
        /** Wave color as RGBA array, alpha = intensity (0-1) */
        color?: number[];
        /** Wave color blending mode (defaults to 'replace') */
        colorBlendMode?: BlendMode;
        /** Axis for displacement (defaults to 'y') */
        displacementAxis?: 'x' | 'y' | 'z';
        /** Displacement as percentage of model size (defaults to 0.02) */
        displacement?: number;
        /** Radius inside which waves are disabled (defaults to 0) */
        exclusionRadius?: number;
    };
}
```

### Colliders

Colliders are invisible primitives or custom `.glb` meshes loaded into the scene. They can be defined in the scene config or added at runtime.

Procedural shapes (`box`, `sphere`, `cylinder`, `plane`) all have unit size 1 by default. Scaling is done via `transform.scale`.

```typescript
type ColliderShape = 'box' | 'sphere' | 'cylinder' | 'plane';

/**
 * Collider semantic role:
 * - 'obstacle': camera cannot enter the volume (default)
 * - 'containment': camera cannot leave the volume
 */
type ColliderRole = 'obstacle' | 'containment';

type ColliderConfig = {
    /** Optional identifier (auto-generated if omitted) */
    id?: string;
    /** Per-collider transform applied within the scene coordinate space */
    transform?: ObjectTransform;
    /** Collider role for camera collision (defaults to 'obstacle') */
    role?: ColliderRole;
} & ({ shape: ColliderShape } | { url: string });

/**
 * Camera collider shape.
 * Currently only 'sphere'; future shapes (e.g. 'capsule') will extend this union.
 */
type CameraColliderShape = 'sphere';

/**
 * Camera collision configuration.
 * All fields are optional — defaults are used when omitted.
 * Shape defaults to 'sphere'. When new shapes are added, this type
 * will become a discriminated union keyed by `shape`.
 */
type CameraCollisionConfig = {
    /** Camera collider shape (default: 'sphere') */
    shape?: CameraColliderShape;
    /** Camera sphere radius in meters (default: 0.15) */
    radius?: number;
    /** Contact offset buffer in meters (default: 0.01) */
    skin?: number;
    /** Slide iterations per substep (default: 3) */
    maxIterations?: number;
    /** Movement subdivision for high-speed stability (default: 4) */
    maxSubsteps?: number;
};

interface SceneCollisionConfig {
    /** Master switch for camera collision resolution (default: false) */
    enabled?: boolean;
    /** List of colliders to load */
    colliders?: ColliderConfig[];
    /** Camera collision solver parameters */
    camera?: CameraCollisionConfig;
}
```

**Collider Roles:**

- **obstacle** (default): The camera cannot enter this volume. When the camera sphere hits an obstacle, it slides along the surface.
- **containment**: The camera cannot leave this volume. The camera sphere is clamped to stay inside the collider bounds. Only primitive shapes (box, sphere, cylinder) are supported for containment in V1.

**Scene config example:**

```typescript
const scene: Scene = {
    // ...
    settings: {
        collisions: {
            enabled: true,
            camera: { radius: 0.15, skin: 0.01 },
            colliders: [
                {
                    id: 'floor',
                    shape: 'box',
                    role: 'obstacle',
                    transform: {
                        position: [0, -1, 0],
                        scale: [10, 0.1, 10],
                    },
                },
                {
                    id: 'boundary',
                    shape: 'box',
                    role: 'containment',
                    transform: { scale: [20, 20, 20] },
                },
                { shape: 'sphere' },
                { url: 'https://example.com/custom-collider.glb', id: 'walls' },
            ],
        },
    },
};

engine.loadScene(scene);
```

**Runtime API:**

```typescript
// Add a procedural collider
const boxId = await engine.addCollider({
    shape: 'box',
    id: 'my-box',
    transform: { position: [0, 0, 0], scale: [2, 0.1, 2] },
});

// Add a custom .glb collider
const customId = await engine.addCollider({
    url: 'https://example.com/collider.glb',
    id: 'my-custom',
});

// List all collider IDs
const ids = engine.getColliderIds(); // ['my-box', 'my-custom']

// Remove a collider
engine.removeCollider(boxId);
```

**Collision Settings API:**

```typescript
// Read collision config
engine.getSceneCollisions();

// Patch: merge with existing config (only overwrite supplied fields)
engine.setSceneCollisions({ enabled: true, camera: { radius: 0.2 } }, { mode: 'patch' });

// Reset: replace the entire config
engine.setSceneCollisions({ enabled: false }, { mode: 'reset' });

// Clear all collision settings
engine.setSceneCollisions(undefined, { mode: 'reset' });

// Colliders are merged by id: existing are updated, new are appended
engine.setSceneCollisions({ colliders: [{ id: 'wall', shape: 'box' }] }, { mode: 'patch' });
```

### Scene State

The engine exposes scene state through a unified event and getter:

```typescript
/** Observable scene states */
type SceneState = 'preview' | 'reveal' | 'scene' | 'unreveal';

// Listen to state changes
engine.on('scene:state-changed', ({ prevState, curState }) => {
    console.log(`Scene state: ${prevState} -> ${curState}`);
    // prevState: previous state (may be undefined on first emission)
    // curState: current state
});

// Programmatically control state
engine.setSceneState('scene'); // Reveal splats
engine.setSceneState('preview'); // Hide splats, show preview
engine.setSceneState('preview', { releaseResources: true }); // Hide and free memory
// releaseResources priority: SceneTransitionOptions.releaseResources > appearance.releaseResources > false

// Instant transition without animation (useful when canvas is off-screen)
engine.setSceneState('scene', { skipAnimation: true });
engine.setSceneState('preview', { skipAnimation: true, releaseResources: true });

// ⚠️ Calling setSceneState() during active page scrolling may cause scroll freezes
// due to synchronous WebGL operations on the first animation frame.
// When embedding the engine in a scrollable page, use a debounced
// IntersectionObserver instead of direct calls.
// See docs/scroll-freeze-workaround.md for details and a complete example.

// Manual scene transition — override transition mode via loadScene overrides.
// Overrides are deep-merged into the scene: only specified fields are changed.
engine.loadScene(scene, {
    settings: { appearance: { transitionMode: 'manual' } },
});

// Or set the default transition mode in scene appearance settings:
// scene.settings.appearance.transitionMode = 'manual';
// engine.loadScene(scene); // will use 'manual' from appearance settings

engine.on('scene:loaded', () => {
    // Scene is loaded but still showing preview model.
    // Reveal when ready (e.g. after UI animation, user action, etc.)
    engine.setSceneState('scene');
});
```

**State transitions:**

| State      | Description                                               | POI visibility |
| ---------- | --------------------------------------------------------- | -------------- |
| `preview`  | Showing preview model only                                | Hidden         |
| `reveal`   | Transitioning from preview to scene (splats appearing)    | Hidden         |
| `scene`    | Showing splat scene                                       | Fade in        |
| `unreveal` | Transitioning from scene to preview (splats disappearing) | Fade out       |

POI markers are only visible in `scene` state. They fade in (300ms CSS transition) when the scene enters `scene` and fade out when it transitions to any other state.

### Camera State

All properties are optional - defaults will be used for missing values.

```typescript
interface CameraState {
    position?: number[]; // [x, y, z] in meters - defaults to [0, 0, 3]
    quaternion?: number[]; // [x, y, z, w]
    fov?: number; // field of view in degrees - defaults to 60
    orbitTarget?: number[]; // [x, y, z] in meters - defaults to [0, 0, 0]
    near?: number; // near clipping plane in meters - defaults to 0.1
    far?: number; // far clipping plane in meters - defaults to 10000
}
```

### Animated Camera Transitions

`setCameraState` supports smooth animated transitions via options:

```typescript
// Instant snap (default)
engine.setCameraState({ position: [0, 1, 5] });

// Animated transition
engine.setCameraState({ position: [0, 1, 5] }, { isAnimated: true });

// Animated with custom duration
engine.setCameraState({ position: [0, 1, 5] }, { isAnimated: true, animationDuration: 800 });

// Animated transition with collision resolution active
engine.setCameraState({ position: [0, 1, 5] }, { isAnimated: true, flightAvoidCollisions: true });
```

Animated transitions emit `camera:transition-start`, `camera:transition-end`, and `camera:transition-stop` events (see [Events](#events)).

By default, collision resolution is skipped during animated transitions (`flightAvoidCollisions` defaults to `false`). Set `flightAvoidCollisions: true` to keep collisions active during the animation.

POI camera focus also uses animated transitions — configure per-POI via `animationDuration` and `flightAvoidCollisions` fields, or set scene-level defaults on `SceneAnnotations`.

### Camera Controller Settings

All properties are optional - defaults will be used for missing values.

> For detailed documentation on each setting (input methods, speed model, joystick modes, tap-hold gestures, defaults rationale), see [docs/camera-controller.md](docs/camera-controller.md).

```typescript
interface CameraControllerSettings {
    orbit?: {
        dampingFactor?: number; // defaults to 0.1
        rotateSpeed?: number; // defaults to 0.5
        zoomSpeed?: number; // defaults to 1.0
        panSpeed?: number; // defaults to 0.8
        minDistance?: number; // meters, defaults to 0.5
        maxDistance?: number; // meters, defaults to 1000
        maxPolarAngle?: number; // radians, defaults to Math.PI
    };
    fps?: {
        pointerRotateSpeed?: number; // defaults to 0.002
        moveSpeed?: number; // master speed (m/s), defaults to 2.0 — derives scroll/pinch/slide/tapHold
        rollSpeed?: number; // radians per second, defaults to 0.0
        shiftMultiplier?: number; // defaults to 2.5
        capsMultiplier?: number; // defaults to 4.0
        ctrlMultiplier?: number; // defaults to 0.5
        scrollSpeed?: number; // mouse scroll wheel, derived from moveSpeed × 0.0025
        pinchSpeed?: number; // trackpad/touch pinch gesture, derived from moveSpeed × 0.025
        slideSpeed?: number; // two-finger swipe / right-click drag, derived from moveSpeed × 0.006
        touchType?: TouchType; // 'joystick' | 'default', defaults to 'default'
        joystick?: JoystickOptions; // only used when touchType is 'joystick'
        tapHoldMoveSpeed?: number; // double/triple-tap-hold speed, derived from moveSpeed (0 = disable)
        tapHoldWindowMs?: number; // max time between taps (ms), defaults to 400
        tapHoldDistancePx?: number; // max distance between taps (px), defaults to 25, 0 = disable
    };
}
```

### Camera Constraints (experimental)

Constraints limit camera rotation and position. They are applied continuously while set, including during manual user control and route playback.

```typescript
interface CameraConstraints {
    rotation?: RotationConstraints;
    position?: PositionConstraints;
}

interface RotationConstraints {
    /** Completely lock all rotation */
    locked?: boolean;
    /** Pitch (X-axis) constraints in radians */
    pitch?: { min?: number; max?: number; locked?: boolean };
    /** Yaw (Y-axis) constraints in radians */
    yaw?: { min?: number; max?: number; locked?: boolean };
    /** Roll (Z-axis) constraints in radians */
    roll?: { min?: number; max?: number; locked?: boolean };
    /** Force camera to look at specific target */
    lookAt?: { target: [number, number, number]; locked?: boolean };
    /** Constrain look direction within a cone around target */
    lookAtCone?: { target: [number, number, number]; maxAngle: number };
}

interface PositionConstraints {
    /** Bounding box for camera position */
    bounds?: { min?: [number, number, number]; max?: [number, number, number] };
    /** Lock individual axes to current value */
    locked?: { x?: boolean; y?: boolean; z?: boolean };
}
```

#### Constraints Examples

```typescript
// Limit pitch rotation to ±45 degrees
engine.setCameraConstraints({
    rotation: {
        pitch: { min: -Math.PI / 4, max: Math.PI / 4 },
    },
});

// Lock camera to look at a specific point
engine.setCameraConstraints({
    rotation: {
        lookAt: { target: [0, 0, 0], locked: true },
    },
});

// Constrain camera look direction within a 30° cone
engine.setCameraConstraints({
    rotation: {
        lookAtCone: { target: [0, 0, 0], maxAngle: Math.PI / 6 },
    },
});

// Restrict camera position to a bounding box
engine.setCameraConstraints({
    position: {
        bounds: { min: [-10, 0, -10], max: [10, 5, 10] },
    },
});

// Lock camera height (Y axis)
engine.setCameraConstraints({
    position: {
        locked: { y: true },
    },
});

// Clear all constraints
engine.setCameraConstraints(null);
```

### Render Settings

All properties are optional — defaults will be used for missing values.
Default values are sourced from `DEFAULT_RENDER_SETTINGS` and match Spark defaults unless noted.

> For detailed documentation on each setting (tier eligibility, visual cost analysis, mutability matrix, built-in presets), see [docs/render-settings.md](docs/render-settings.md).

```typescript
interface RenderSettings {
    /** Anti-aliasing blur added to splat covariance diagonal (default: 0.3) */
    blurAmount?: number;
    /** Pre-blur enlarging splats without opacity correction (default: 0) */
    preBlurAmount?: number;
    /** Max std deviations to render Gaussians; lower = faster (default: √8 ≈ 2.83) */
    maxStdDev?: number;
    /** Absolute device pixel ratio for WebGL renderer; 0 or undefined falls back to window.devicePixelRatio (default: window.devicePixelRatio) */
    pixelRatio?: number;
    /** Multiplier applied to the resolved root DPR; primarily used by tier presets (low: 0.75) for device-proportional downscale (default: 1) */
    pixelRatioScale?: number;
    /** Minimum pixel radius for splat rendering (default: 0) */
    minPixelRadius?: number;
    /** Maximum pixel radius for splat rendering (default: 512) */
    maxPixelRadius?: number;
    /** Auto-update Gsplat collection after each frame (default: false) */
    autoUpdate?: boolean;

    // Sorting
    /** Sort by radial distance (true) or Z-depth (false) (default: true) */
    sortRadial?: boolean;

    // Advanced renderer options
    /** Use premultiplied alpha for splat RGB accumulation (default: true) */
    premultipliedAlpha?: boolean;
    /** Encode splat RGB as linear (sRGB→linear pow 2.2) (default: false) */
    encodeLinear?: boolean;
    /** Update Gsplats before rendering instead of after (default: false) */
    preUpdate?: boolean;
    /** Minimum alpha threshold; below this splats are discarded (default: ~0.002) */
    minAlpha?: number;
    /** Enable 2D Gaussian Splatting rendering (default: false) */
    enable2DGS?: boolean;
    /** Focal plane distance for depth-of-field effect (default: 0 = disabled) */
    focalDistance?: number;
    /** Aperture angle in radians for DoF (default: 0 = disabled) */
    apertureAngle?: number;
    /** Gaussian kernel falloff modulation, 0 = flat, 1 = normal (default: 1.0) */
    falloff?: number;
    /** X/Y frustum clipping factor for Gsplat centers (default: 1.4) */
    clipXY?: number;
    /** Projected splat scale adjustment to match other renderers (default: 1.0) */
    focalAdjustment?: number;

    // LOD rendering
    /** Enable LOD system for progressive splat refinement (default: false, auto-enabled for streaming) */
    enableLod?: boolean;
    /** Enable LOD page fetching — toggle at runtime to pause/resume chunk streaming (default: true) @experimental */
    enableLodFetching?: boolean;
    /** Target splat count for LOD rendering (default: platform-dependent) */
    lodSplatCount?: number;
    /** Multiplier for the LOD splat budget (default: 1.0) */
    lodSplatScale?: number;
    /** Minimum splat pixel size threshold for LOD rendering (default: 1.0) */
    lodRenderScale?: number;
    /** Inflate LOD splats so opacity stays ≤ 1.0, softer AA (default: false) */
    lodInflate?: boolean;
    /** Splat count for low-res LOD raycast sample; 0 = disable (default: 25000) */
    lodRaycast?: number;
    /** Regeneration interval for raycast sample in ms (default: 500) */
    lodRaycastIntervalMs?: number;
    /** Minimum interval between sort operations in ms (default: 0) */
    minSortIntervalMs?: number;

    // Foveation (experimental — LOD/streaming scenes only, no effect on full-download scenes)
    /** Full-resolution foveation cone half-angle in degrees (default: 90) */
    coneFov0?: number;
    /** Reduced-resolution foveation cone half-angle in degrees (default: 120) */
    coneFov?: number;
    /** Detail scale factor at the coneFov boundary, 0..1 (default: 0.4) */
    coneFoveate?: number;
    /** Detail scale factor for splats behind the viewer, 0..1 (default: 0.2) */
    behindFoveate?: number;

    // Init-only settings (require engine re-creation to change)
    /** Number of parallel chunk fetchers for streaming. Spark default: 3 */
    numLodFetchers?: number;
    /** Use float32 paged splat encoding for large scenes. Spark default: false */
    pagedExtSplats?: boolean;
    /** Max splats in the paged GPU pool. **Init-only.** */
    maxPagedSplats?: number;
    /** Use Float32 intermediate accumulator. **Init-only.** Default: false */
    accumExtSplats?: boolean;
    /** Enable covariance accumulator encoding. **Init-only.** Default: false */
    covSplats?: boolean;

    // Splat encoding ranges (require page reload to take effect)
    /** Splat encoding ranges for packed data interpretation */
    splatEncoding?: SplatEncoding;
}

interface SplatEncoding {
    /** Min RGB value for color encoding (default: 0) */
    rgbMin?: number;
    /** Max RGB value for color encoding; >1 for hyper-saturated (default: 1) */
    rgbMax?: number;
    /** Min log-scale for splat scale encoding (default: -12) */
    lnScaleMin?: number;
    /** Max log-scale for splat scale encoding (default: 9) */
    lnScaleMax?: number;
    /** Max 1st-order SH value; symmetric range [-sh1Max, sh1Max] (default: 1) */
    sh1Max?: number;
    /** Max 2nd-order SH value; symmetric range [-sh2Max, sh2Max] (default: 1) */
    sh2Max?: number;
    /** Max 3rd-order SH value; symmetric range [-sh3Max, sh3Max] (default: 1) */
    sh3Max?: number;
    /** Extended 0..2 opacity for LOD splats (default: false) */
    lodOpacity?: boolean;
}
```

### Shared Lib Types

```typescript
/** 3D object transform. Exported from lib/types.ts. */
interface ObjectTransform {
    /** Rotation as [x, y, z, w] quaternion */
    quaternion?: number[];
    /** Position offset [x, y, z] */
    position?: number[];
    /** Scale factor: uniform number or per-axis [x, y, z] (defaults to 1) */
    scale?: number | number[];
}

/** Gizmo transform mode */
type ObjectTransformMode = 'translate' | 'rotate' | 'scale';
```

### Environment Settings

The engine automatically selects the appropriate skybox resolution based on the device tier (`'low'` → 2K, `'high'` → 4K with a hardware capability guard via `renderer.capabilities`). If the primary resolution fails to load, the engine falls back to the other resolution, then to the background color. The `url2k`/`urls2k` fields are optional — when omitted, `url`/`urls` is used for all tiers.

```typescript
type RgbaColor = number[];

// Cubemap skybox (6 face textures, optionally at two resolutions)
interface SkyboxCubemap {
    mode: 'cubemap';
    /** URLs for 6 cube faces at ≤ 2048 px per face. Used on low tier. Falls back to `urls` when omitted. Order: [+X, -X, +Y, -Y, +Z, -Z] */
    urls2k?: [string, string, string, string, string, string];
    /** URLs for 6 cube faces. Used on high tier. Order: [+X, -X, +Y, -Y, +Z, -Z] */
    urls: [string, string, string, string, string, string];
    /** Brightness of the skybox texture (default: 1) */
    intensity?: number;
    /** Blur amount 0-1 (default: 0) */
    blur?: number;
    /** Rotation in degrees as [x, y, z] Euler angles */
    rotation?: [number, number, number];
}

// Equirectangular panorama (single 360° image, supports LDR and HDR)
interface SkyboxEquirectangular {
    mode: 'equirectangular';
    /** URL of 360° panorama at ≤ 2048 px (longer dimension). Used on low tier. Falls back to `url` when omitted. */
    url2k?: string;
    /** URL of 360° panorama. Used on high tier, and as fallback for low tier when `url2k` is omitted. */
    url: string;
    /** Brightness of the skybox texture (default: 1) */
    intensity?: number;
    /** Blur amount 0-1 (default: 0) */
    blur?: number;
    /** Rotation in degrees as [x, y, z] Euler angles */
    rotation?: [number, number, number];
}

// Ground-projected skybox (panorama projected onto a virtual ground plane)
// Uses a mesh internally — `blur` has no effect in this mode
interface SkyboxGroundProjected {
    mode: 'ground-projected';
    /** URL of 360° panorama at ≤ 2048 px (longer dimension). Used on low tier. Falls back to `url` when omitted. */
    url2k?: string;
    /** URL of 360° panorama. Used on high tier, and as fallback for low tier when `url2k` is omitted. */
    url: string;
    /** Camera height above the virtual ground plane (default: 15) */
    height?: number;
    /** Radius of the skybox sphere (default: 100) */
    radius?: number;
    /** Brightness of the skybox material (default: 1) */
    intensity?: number;
    /** Rotation in degrees as [x, y, z] Euler angles */
    rotation?: [number, number, number];
}

type SkyboxSettings = SkyboxCubemap | SkyboxEquirectangular | SkyboxGroundProjected;

interface EnvironmentSettings {
    /**
     * Background color shown during preview/reveal phase.
     * If skybox is specified, this color is shown until reveal completes.
     * If no skybox, this color remains as the background.
     */
    background?: RgbaColor;
    /** Skybox texture configuration (cubemap, equirectangular, or ground-projected) */
    skybox?: SkyboxSettings;
}
```

If only one resolution is available, simply omit `url2k`/`urls2k` — the engine will use `url`/`urls` for all tiers.

#### Environment Examples

```typescript
// Solid color background
engine.setEnvironment({
    background: [0.1, 0.1, 0.15, 1],
});

// Cubemap skybox (no fallback color)
engine.setEnvironment({
    skybox: {
        mode: 'cubemap',
        urls2k: ['2k/px.png', '2k/nx.png', '2k/py.png', '2k/ny.png', '2k/pz.png', '2k/nz.png'],
        urls: ['4k/px.png', '4k/nx.png', '4k/py.png', '4k/ny.png', '4k/pz.png', '4k/nz.png'],
    },
});

// Equirectangular panorama with texture options
engine.setEnvironment({
    skybox: {
        mode: 'equirectangular',
        url2k: 'panorama-2k.jpg',
        url: 'panorama-4k.jpg',
        intensity: 0.8, // slightly dimmed
        blur: 0.3, // subtle blur
        rotation: [0, 180, 0], // rotated 180° around Y
    },
});

// HDR panorama (auto-detected by .hdr extension), single resolution
engine.setEnvironment({
    skybox: {
        mode: 'equirectangular',
        url: 'environment.hdr',
    },
});

// Ground-projected skybox (panorama wraps around at ground level)
engine.setEnvironment({
    skybox: {
        mode: 'ground-projected',
        url: 'environment.hdr',
        height: 15, // camera height above ground plane
        radius: 100, // skybox sphere radius
    },
});

// Skybox with fallback color during preview/reveal
// Color is shown until reveal animation completes, then skybox appears
engine.setEnvironment({
    background: [0.05, 0.05, 0.1, 1], // dark blue shown during loading/reveal
    skybox: {
        mode: 'equirectangular',
        url2k: 'panorama-2k.hdr', // optional low-res variant
        url: 'panorama-4k.hdr',
    },
});
```

### Events

```typescript
// Subscribe to events
engine.on('scene:loading', ({ streaming, hasPreview }) => {
    console.log(`Loading started (streaming: ${streaming}, preview: ${hasPreview})`);
});

engine.on('scene:progress', ({ preview, download, streaming }) => {
    if (download) {
        const pct = download.totalSize > 0 ? (download.loadedSize / download.totalSize) * 100 : 0;
        console.log(`Downloading: ${pct.toFixed(1)}%`);
    }
    if (streaming) {
        console.log(`Streaming: ${streaming.loadedChunks}/${streaming.totalChunks} chunks`);
    }
});

engine.on('scene:loaded', ({ splatsCount }) => {
    console.log(`Loaded ${splatsCount} splats`);
});

engine.on('scene:error', ({ error }) => {
    console.error('Load failed:', error);
});

engine.on('poi:select', ({ poi }) => {
    console.log('Selected POI:', poi.id, poi.label);
});

engine.on('poi:update', ({ poi }) => {
    console.log('POI updated:', poi.id, poi.position);
});

engine.on('camera:update', ({ state }) => {
    console.log('Camera moved:', state.position);
});

engine.on('camera:transition-start', ({ state, duration }) => {
    console.log('Camera transition start:', state, duration);
});

engine.on('camera:transition-end', ({ state, duration }) => {
    console.log('Camera transition end:', state, duration);
});

engine.on('camera:transition-stop', ({ state, duration }) => {
    console.log('Camera transition stop:', state, duration);
});

engine.on('scene:state-changed', ({ prevState, curState }) => {
    console.log(`Scene: ${prevState} -> ${curState}`);
});

// Camera route events
engine.on('route:start', ({ routeId, waypointIndex, route }) => {
    console.log('Route started:', routeId);
});

engine.on('route:end', ({ routeId }) => {
    console.log('Route completed:', routeId);
});

engine.on('route:stop', ({ routeId }) => {
    console.log('Route stopped:', routeId);
});

engine.on('route:pause', ({ routeId }) => {
    console.log('Route paused:', routeId);
});

engine.on('route:resume', ({ routeId }) => {
    console.log('Route resumed:', routeId);
});

engine.on('route:waypoint-reached', ({ routeId, waypointIndex }) => {
    console.log(`Reached waypoint ${waypointIndex} on route ${routeId}`);
});

// Joystick events
engine.on('camera-controller:joystick-active', ({ active, mode }) => {
    console.log(`Joystick ${active ? 'started' : 'ended'} (mode: ${mode})`);
});

engine.on('camera-controller:joystick-input', ({ x, y }) => {
    console.log(`Joystick input: ${x.toFixed(2)}, ${y.toFixed(2)}`);
});

// Unsubscribe
engine.off('scene:loaded', myHandler);

// Subscribe once
engine.once('scene:loaded', () => {
    console.log('First load complete');
});
```

### Scene Annotations (POI)

POI markers are managed by the engine and rendered as an HTML overlay layer above the canvas. The layer is hidden by default and fades in/out automatically based on the [scene state](#scene-state) — markers appear when the scene reaches `scene` state and fade out when it leaves to any other state (300ms CSS transition).

```typescript
interface Poi {
    id: string;
    label?: string;
    position: number[]; // [x, y, z] in meters
    camera?: CameraState;
    animationDuration?: number; // camera focus animation duration in ms
    flightAvoidCollisions?: boolean; // keep collisions active during camera navigation (default: false)
    disableOcclusion?: boolean; // skip occlusion checks — marker is never dimmed (default: false)
}

interface SceneAnnotations {
    description?: string;
    pois?: Poi[];
    autoSelect?: boolean;
    disableFocusOnSelect?: boolean;
    disableOcclusion?: boolean; // scene-level default for Poi.disableOcclusion (default: false)
    flightAvoidCollisions?: boolean; // scene-level default for Poi.flightAvoidCollisions (default: false)
}
```

```typescript
const scene: Scene = {
    // ...
    annotations: {
        pois: [
            {
                id: 'entry',
                label: 'Main entrance',
                position: [1.2, 0.3, -0.8],
                camera: { position: [1, 1, 2], orbitTarget: [0, 0, 0] },
                animationDuration: 800,
            },
        ],
    },
};

engine.loadScene(scene);
```

After loading a scene, update annotations at runtime with `setSceneAnnotations`:

```typescript
// Patch mode — merge by id, keep existing POIs, update scalar fields
engine.setSceneAnnotations(
    {
        disableFocusOnSelect: true,
        pois: [
            { id: 'entry', label: 'Updated label' }, // merges into existing POI
            { id: 'new-poi', label: 'Added', position: [0, 1, 0] }, // new POI
        ],
    },
    { mode: 'patch' }
);

// Reset mode — replace entire annotations object
engine.setSceneAnnotations(
    {
        pois: [{ id: 'only-poi', label: 'Solo', position: [0, 0, 0] }],
    },
    { mode: 'reset' }
);
```

### Styles

The engine does **not** auto-import POI styles. You must import the CSS
manually to enable POI rendering.

```typescript
import '@datum-sdk/engine/index.min.css';
```

An unminified copy is also emitted as `dist/index.css` for debugging
or custom styling workflows.

To customize POI styles, include your overrides after the engine import
and target the `dsdk-engine` and `dsdk-poi-*` classes. You can also
override the CSS variables used by the default theme.

Available CSS variables:

- `--border-active` — active/selected outline color (default: `rgba(38, 38, 38, 0.8)` or `rgba(253, 253, 253, 0.8)` in selected state)
- `--border-accent` — outer glow ring color (default: `rgba(38, 38, 38, 0.4)` or `rgba(253, 253, 253, 0.4)` in selected state)
- `--transparent-dark-500` — label background color (default: `rgba(38, 38, 38, 0.5)`)
- `--font` — label font family (default: `sans-serif`)

```css
/* Example: override POI colors and label styling */
.dsdk-engine {
    --border-active: rgba(0, 0, 0, 0.8);
    --border-accent: rgba(0, 0, 0, 0.3);
}

.dsdk-engine .dsdk-poi-marker__label {
    background: rgba(0, 0, 0, 0.75);
    font:
        600 13px/18px 'Inter',
        sans-serif;
}
```

### Methods

#### Core

- `destroy()` — Destroy viewer and release resources
- `loadScene(scene, overrides?)` — Load a new scene (clears existing). Optional `Partial<Scene>` overrides are deep-merged into the scene
- `requestRender(): void` — request a frame and wake idle scheduler if paused
- `getCurrentScene(): Scene | null`
- `isLoading(): boolean`

#### Three.js Access

- `getCamera(): PerspectiveCamera`
- `getRenderer(): WebGLRenderer`
- `getContainer(): HTMLElement` — Returns the root HTML element that contains the engine canvas
- `getScene(): Scene`
- `getSpark(): SparkRenderer | null` — Returns `null` when using the internal legacy renderer
- `getSplatMesh(): SplatMesh | null`

#### Picking

- `pickPoint(clientX, clientY): PickResult | null` — Raycast from screen coordinates against the SplatMesh surface. Returns `{ point: number[], distance: number }` for the nearest hit, or `null` if no splat mesh is loaded or the ray misses.

```typescript
canvas.addEventListener('click', (e) => {
    const hit = engine.pickPoint(e.clientX, e.clientY);
    if (hit) {
        console.log('World point:', hit.point, 'Distance:', hit.distance);
    }
});
```

#### Camera Control

- `getCameraState(): CameraState`
- `setCameraState(state, options?): void`
- `resetCamera(forceDefaults?): void`

#### Controls

- `getControlsMode(): ControlsMode`
- `setSceneControlsMode(mode): void` — persists the mode to the current scene's `settings.cameraMode`

> **Per-scene controls mode:** `SceneSettings.cameraMode` (`'fps' | 'orbit'`) is applied automatically on `loadScene()`. Falls back to the `controlsMode` from engine options if not specified. Calling `setSceneControlsMode()` at runtime also updates the current scene object.
>
> To change controls mode or enabled state **without** persisting to the scene, use `setRuntimeOptions()` (see below).

#### Virtual Joystick

On-screen joystick for FPS camera movement on touch devices. Two placement modes are available:

- **`'static'`** — joystick is rendered at a fixed position (bottom-left by default). Dragging the knob controls movement; touching anywhere else controls look.
- **`'dynamic'`** — touching the left half of the container spawns a joystick at the touch point. The right half controls look. The joystick disappears on finger lift.

The joystick is only active when controls mode is `'fps'`. It auto-disables in orbit mode and re-enables when switching back.

**Via scene settings:**

```typescript
const scene: Scene = {
    settings: {
        cameraController: {
            fps: {
                touchType: 'joystick',
                joystick: { mode: 'dynamic' },
                // or: joystick: { mode: 'static', size: 150, position: { bottom: 40, left: 40 } },
            },
        },
    },
};
```

**Via engine defaults (applied when scene has no joystick config):**

```typescript
const engine = new DatumEngine({
    cameraController: {
        fps: { touchType: 'joystick', joystick: { mode: 'static' } },
    },
});
```

**Changing at runtime:**

```typescript
// Update default settings (scene settings take priority)
engine.setCameraControllerSettings({
    fps: { touchType: 'joystick', joystick: { mode: 'dynamic' } },
});

// Or override current scene settings directly
engine.setSceneCameraControllerSettings({
    fps: { touchType: 'joystick', joystick: { mode: 'static' } },
});

// Disable joystick for current scene:
engine.setSceneCameraControllerSettings({
    fps: { touchType: 'default' },
});
```

**Types:**

```typescript
type TouchType = 'joystick' | 'default';
type JoystickMode = 'static' | 'dynamic';

interface JoystickOptions {
    mode: JoystickMode;
    size?: number; // base circle diameter in px (default: 120)
    deadZone?: number; // fraction of radius, 0–1 (default: 0.15)
    position?: {
        // static mode only
        bottom?: number; // px from bottom (default: 30)
        left?: number; // px from left (default: 30)
    };
}

interface CameraControllerEventMap {
    'camera-controller:joystick-active': { active: boolean; mode: JoystickMode };
    'camera-controller:joystick-input': { x: number; y: number };
}
```

**CSS custom properties** for theming:

| Property                             | Default                    |
| ------------------------------------ | -------------------------- |
| `--datum-joystick-base-color`        | `rgba(255, 255, 255, 0.2)` |
| `--datum-joystick-base-border`       | `rgba(255, 255, 255, 0.4)` |
| `--datum-joystick-knob-color`        | `rgba(255, 255, 255, 0.5)` |
| `--datum-joystick-knob-active-color` | `rgba(100, 150, 255, 0.7)` |

#### Double/Triple-Tap-Hold Movement

On touch devices in FPS mode, double-tapping and holding moves the camera toward the tapped screen point. Triple-tap-hold does the same at 5x speed (hardcoded in Spark). The gesture uses raycasting to determine the movement direction from the tap position. Speed ramps up from 0 to full over 1 second of hold.

With joystick enabled, tap-hold only works in the **look zone** (right side of the screen). The joystick zone (left side) handles movement via the virtual stick — taps there are intercepted by the joystick layer and don't reach the gesture detector. This is intentional: left hand controls the joystick, right hand can use tap-hold to "go to point".

**Speed comparison:**

| Input                  | Speed    |
| ---------------------- | -------- |
| WASD / double-tap-hold | 2.0 m/s  |
| Shift+WASD             | 5.0 m/s  |
| Caps+WASD              | 8.0 m/s  |
| Triple-tap-hold        | 10.0 m/s |

**Settings:**

| Setting             | Default | Description                                                                                                                                            |
| ------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `tapHoldMoveSpeed`  | `2.0`   | Movement speed (m/s). Matches `moveSpeed` so double-tap-hold feels like WASD. Triple-tap applies a hardcoded 5x on top. Set to `0` to disable entirely |
| `tapHoldWindowMs`   | `400`   | Maximum time (ms) between taps to count as double/triple-tap. 400ms is the OS-standard double-click window                                             |
| `tapHoldDistancePx` | `25`    | Maximum distance (px) between taps. 25px reduces false triggers from finger drift (~8 physical px at DPR 3). `0` disables tap-hold entirely            |

```typescript
// Disable tap-hold movement
engine.setCameraControllerSettings({
    fps: { tapHoldMoveSpeed: 0 },
});

// Slower tap-hold, tighter recognition window
engine.setSceneCameraControllerSettings({
    fps: { tapHoldMoveSpeed: 0.5, tapHoldWindowMs: 300, tapHoldDistancePx: 30 },
});
```

#### Runtime Options

Non-persisting overrides for engine module state. Use for temporary changes (e.g. disabling collisions while an editor is active) with a save/restore pattern.

- `getRuntimeOptions(): ResolvedRuntimeOptions` — read current live state from engine modules (not from `currentScene`)
- `setRuntimeOptions(options: RuntimeOptions): void` — apply partial overrides (patch semantics); does **not** write to the current scene

```typescript
// Save current state
const saved = engine.getRuntimeOptions();

// Override
engine.setRuntimeOptions({ controls: { enabled: false }, collisions: { enabled: false } });

// Restore
engine.setRuntimeOptions(saved);
```

`RuntimeOptions` fields (all optional):

| Field                               | Type           | Description                                                  |
| ----------------------------------- | -------------- | ------------------------------------------------------------ |
| `deviceTier`                        | `DeviceTier`   | Override device tier; re-applies render settings merge chain |
| `controls.mode`                     | `ControlsMode` | Controls mode (`'orbit'` / `'fps'`)                          |
| `controls.enabled`                  | `boolean`      | Enable/disable user camera controls                          |
| `collisions.enabled`                | `boolean`      | Enable/disable collision resolution                          |
| `annotations.disableFocusOnSelect`  | `boolean`      | Disable automatic camera focus on POI selection              |
| `annotations.disablePoiInteraction` | `boolean`      | Disable pointer interaction with POI markers                 |

#### Render Settings

- `getRenderSettings(): RenderSettings` — get default render settings (as set via `setRenderSettings` or constructor)
- `setRenderSettings(settings): void` — set default render settings (scene settings take priority)
- `getSceneRenderSettings(): RenderSettings | undefined` — get current scene's render settings
- `setSceneRenderSettings(settings | undefined): void` — set/clear scene render settings
- `getCurrentRenderSettings(): Required<RenderSettings>` — get fully resolved render settings as applied to the Spark renderer (all fields filled)
- `getTierRenderSettings(tier): TierRenderSettings` — get tier-specific render setting overrides for a given device tier
- `setTierRenderSettings(tier, settings, options?): void` — set tier-specific render setting overrides (default `mode: 'patch'`; use `mode: 'reset'` to replace all)
- `getSceneTierRenderSettings(): TierRenderSettingsMap | undefined` — get current scene's per-tier render setting overrides
- `setSceneTierRenderSettings(settings | undefined): void` — set/clear scene per-tier render setting overrides (highest priority in the merge chain)
- `getDevicePixelRatio(): number`

#### Scene Transform

- `getSceneTransform(): Required<ObjectTransform>` — get the current scene transform
- `setSceneTransform(transform, options?): void` — set the visual transform (splat mesh + preview model) without recalculating spatial objects. Options: `{ mode: 'patch' | 'reset' }`
- `resetSceneTransform(): void` — clear the scene transform to defaults
- `transformScene(newTransform): Scene | null` — apply a new scene transform with full spatial recalculation (POIs, colliders, camera routes, initial camera)

#### Streaming / LOD

- `isStreamingActive(): boolean` — whether the current scene uses LOD streaming
- `getStreamingProgress(): StreamingProgress | null` — streaming telemetry snapshot (bytes, chunks, splats, settled) or `null` for non-streaming scenes

#### POI

- `setSceneAnnotations(annotations, options): void` — Update scene annotations. Options: `{ mode: 'patch' | 'reset' }`. Patch merges POIs by id and updates scalar fields; reset replaces the entire object.
- `getPoiById(id): Poi | undefined` — Look up a POI by its unique identifier
- `updatePoi(poi, options?): void`
- `removePoi(poiId): void`
- `selectPoi(poiId): void`
- `clearPoiSelection(): void`
- `getFirstVisiblePoi(): Poi | null`
- `getSelectedPoi(): Poi | null`

#### Scene Appearance

- `getSceneState(): SceneState | undefined` — Current scene state, undefined if no scene loaded
- `getSceneAppearanceConfig(): SceneAppearanceConfig`
- `setSceneAppearanceConfig(config): void` — also syncs to `currentScene.settings.appearance`
- `setSceneState(target, options?): void` — Transition to 'preview' or 'scene'. Options: `releaseResources` (free memory on preview), `skipAnimation` (instant transition)
- `replaySceneAppearance(): void`

#### Camera Constraints (experimental)

- `setCameraConstraints(constraints | null): void` — Set or clear camera constraints
- `getCameraConstraints(): CameraConstraints | null` — Get current constraints

#### Camera Controller Settings

- `getCameraControllerSettings(): CameraControllerSettings` — get engine-default settings
- `setCameraControllerSettings(settings): void` — set engine-default settings (includes joystick config via `fps.touchType` / `fps.joystick`)
- `getSceneCameraControllerSettings(): CameraControllerSettings | undefined` — get current scene's settings
- `setSceneCameraControllerSettings(settings): void` — set current scene's settings (includes joystick config)
- `getCurrentCameraControllerSettings(): ResolvedCameraControllerSettings` — effective merged settings with all defaults filled (scene fields override defaults per block)

#### Camera Routes

- `setCameraRoutes(routes | null): void` — Replace all routes or clear; syncs to current scene
- `getCameraRoutes(): CameraRoute[]` — Get all registered routes
- `putCameraRoute(route): void` — Create or update a route; syncs to current scene
- `removeCameraRoute(routeId): void` — Remove a route by id; syncs to current scene
- `startCameraRoute(routeId, options?): void` — Start route playback; clears active camera constraints. Options: `{ mode?, flightAvoidCollisions?, scroll? }`. Pass `scroll` to bind progress to an element's scroll position (see [Scroll-bound routes](#scroll-bound-routes)).
- `getActiveCameraRouteId(): string | null` — Get active route id
- `pauseCameraRoute(): void` — Pause at current position
- `resumeCameraRoute(options?): void` — Resume from paused position
- `stopCameraRoute(): void` — Stop playback (must restart to play again)
- `proceedToNextWaypoint(): void` — Advance to next waypoint (switches to manual mode)
- `proceedToPrevWaypoint(): void` — Go back to previous waypoint (switches to manual mode)
- `setCameraRouteProgress(progress): void` — Set route progress [0, 1]; if the route is in auto mode, switches to manual then seeks
- `getCameraRouteProgress(): number | null` — Get route progress [0, 1] or null if no active route

#### Colliders

- `addCollider(config): Promise<string>` — Add a collider (procedural shape or custom `.glb` URL) and return its ID
- `removeCollider(id): boolean` — Remove a collider by ID
- `getColliderIds(): string[]` — Get all loaded collider IDs
- `getColliderObject(id): THREE.Object3D | null` — Get the Three.js object for a collider
- `getColliderRole(id): ColliderRole` — Get the role of a collider (`'obstacle'` or `'containment'`)
- `getColliderSource(id): string` — Get a human-readable source identifier (shape name, URL, or `'unknown'`)
- `updateColliderRole(id, role): void` — Update the role of a collider
- `updateColliderTransform(id, transform): void` — Update a collider's position, rotation, and/or scale. Applies the transform to the underlying `Object3D` and invalidates the collision snapshot cache so POI occlusion and camera-collision reads see the new pose on the next frame. Editors and tooling should use this instead of mutating `getColliderObject(id).position` directly
- `exportColliderConfig(): ColliderConfig[]` — Export current collider layout as config array
- `getCollisionsRoot(): THREE.Group` — Get the Three.js group containing all collision meshes
- `getCollisionSolveMs(): number` — Last collision solver execution time in milliseconds (0 when disabled or no colliders present)

#### Collision Settings

- `getSceneCollisions(): SceneCollisionConfig | undefined` — Get scene collision settings
- `setSceneCollisions(config | undefined, { mode: 'patch' | 'reset' }): void` — Update collision config (enabled, camera, colliders). Colliders are merged by ID. Pass `undefined` to clear.

#### Environment

- `getEnvironment(): EnvironmentSettings`
- `setEnvironment(settings): void`
- `getSceneEnvironment(): EnvironmentSettings | undefined`
- `setSceneEnvironment(settings): void`
- `getCurrentEnvironment(): EnvironmentSettings`

#### Render Callbacks (for plugins)

- `addBeforeRenderCallback(callback): void`
- `removeBeforeRenderCallback(callback): void`
- `addAfterRenderCallback(callback, order?): void` — `order` controls draw layering (lower = behind)
- `removeAfterRenderCallback(callback): void`

When plugin code mutates visuals outside engine-owned update paths, call `requestRender()` to invalidate and wake rendering.

#### Overlay Order Constants

- `OVERLAY_ORDER_DEBUG` — `0` (DebugOverlay layer)
- `OVERLAY_ORDER_EDITOR` — `100` (editor plugin layer)

### Helpers

The `helpers` namespace provides coordinate conversion and rotation utilities:

```typescript
import { helpers } from '@datum-sdk/engine';

// Convert spherical coordinates to cartesian position
const target: [number, number, number] = [0, 0, 0];
const position = helpers.sphericalToCartesian(target, 5, Math.PI / 4, Math.PI / 3);
// => [x, y, z] camera position at radius=5 from target

// Convert cartesian position back to spherical coordinates
const spherical = helpers.cartesianToSpherical(target, position);
// => { radius, azimuth, polar }

// Convert Euler angles (degrees) to quaternion
const quat = helpers.eulerDegToQuat([0, 45, 0]); // 45° around Y
// => [x, y, z, w]

// Convert quaternion back to Euler angles (degrees)
const euler = helpers.quatToEulerDeg(quat);
// => [0, 45, 0]
```

#### Collider Migration

Migrate legacy scenes with model-local colliders to world-space coordinates:

```typescript
import { helpers } from '@datum-sdk/engine';

const migrated = helpers.migrateCollidersToWorldSpace(legacyScene);
engine.loadScene(migrated);
```

> **Note:** `formatStudioScene` calls this automatically for unversioned scenes. Use `migrateCollidersToWorldSpace` directly only for scenes not coming from the Studio API.

#### Studio Scene Formatter

Convert a raw Datum Studio API response into an engine-compatible `Scene`:

```typescript
import { helpers } from '@datum-sdk/engine';

const response = await fetch(`${studioApiUrl}/scenes/${sceneId}`);
const raw = await response.json();
const scene = helpers.formatStudioScene(raw);
engine.loadScene(scene);
```

The formatter handles all necessary transformations automatically:

- Stamps `version: '0.1'` on the output `Scene`
- Loose `position`/`quaternion`/`scale` fields normalized into `SceneSettings.transform`
- Unversioned (legacy) scenes: colliders migrated from model-local to world-space via `migrateCollidersToWorldSpace`
- Euler angles (ZYX order) to quaternions for scene rotation, camera, and preview transform
- `{x, y, z}` position objects to `[x, y, z]` arrays for annotations
- Nested `background.color` extraction from Studio environment format
- Pass-through of cameraRoutes, cameraController, appearance, and other engine-compatible fields

## Plugins

Optional extensions (stats, debug overlay, editor) live in [`@datum-sdk/plugins`](../plugins). See the [plugins README](../plugins/README.md) for the full API reference.

## Camera Routes

Camera routes animate the camera along a path of waypoints. Routes support auto and manual playback modes, looping, per-waypoint easing, speed/duration control, and camera constraints.

During route playback the engine always switches to FPS camera mode for consistent behavior. The previous controls mode is automatically restored when the route ends or is stopped.

### CameraRoute

```typescript
interface CameraRoute {
    id: string; // Unique route identifier
    waypoints: Waypoint[]; // At least 1 waypoint required
    defaultMode?: 'auto' | 'manual'; // Playback mode (default: 'auto')
    stepSpeed?: number; // Default speed in world units/s
    stepDuration?: number; // Default segment duration in ms (default: 500)
    loop?: boolean; // Loop to first waypoint (default: false)
    flightAvoidCollisions?: boolean; // Keep collisions active during playback (default: false)
}
```

### Waypoint

```typescript
interface Waypoint {
    target?: [number, number, number]; // With orbit: orbit center; without orbit: camera position
    orbit?: OrbitSpherical; // Spherical coords (arc movement around target)
    lookAt?: [number, number, number] | 'target'; // Look-at point (priority over quaternion)
    quaternion?: [number, number, number, number]; // Camera rotation [x, y, z, w]
    fov?: number; // Field of view in degrees
    speed?: number; // Segment speed in world units/s
    duration?: number; // Segment duration in ms
    easing?: Easing; // Easing preset or cubic-bezier
    constraints?: CameraConstraints; // Applied when waypoint is reached
    transitionConstraints?: CameraConstraints; // Applied during transition
    poiId?: string; // Reference to a POI — missing fields derived from POI
    autoAdvance?: boolean; // Skip pause in manual mode (default: false)
}
```

Duration priority: `waypoint.speed` > `waypoint.duration` > `route.stepSpeed` > `route.stepDuration` > 500 ms fallback.

### Route Events

| Event                    | Payload                                                 | Description                             |
| ------------------------ | ------------------------------------------------------- | --------------------------------------- |
| `route:start`            | `{ routeId, waypointIndex, route }`                     | Route playback started                  |
| `route:end`              | `{ routeId, waypointIndex, route }`                     | Route completed naturally               |
| `route:stop`             | `{ routeId, waypointIndex, route }`                     | Route stopped via `stopCameraRoute()`   |
| `route:pause`            | `{ routeId, waypointIndex, route }`                     | Route paused via `pauseCameraRoute()`   |
| `route:resume`           | `{ routeId, waypointIndex, route }`                     | Route resumed via `resumeCameraRoute()` |
| `route:waypoint-reached` | `{ routeId, waypointIndex, route, poiId?, direction? }` | Camera reached a waypoint               |

`route:waypoint-reached` uses `CameraRouteWaypointReachedEvent` — extends `CameraRouteEvent` with an optional `poiId` when the waypoint references a POI and `direction` (`'forward'` or `'backward'`) for every arrival: timed playback (auto/manual) reflects traversal along the route; `setCameraRouteProgress()` uses the seek direction along normalized progress.

### Usage Examples

```typescript
// Auto mode: camera moves through all waypoints automatically
engine.setCameraRoutes([
    {
        id: 'tour',
        waypoints: [
            { target: [0, 1, 5], lookAt: [0, 0, 0], easing: 'ease-in-out' },
            { target: [2, 1, 3], lookAt: [0, 0, 0], duration: 2000 },
        ],
    },
]);
engine.startCameraRoute('tour');

// Manual mode: pauses at each waypoint until you advance
engine.setCameraRoutes([
    {
        id: 'demo-route',
        defaultMode: 'manual',
        waypoints: [{ target: [0, 1, 5] }, { target: [2, 1, 3] }],
    },
]);
engine.startCameraRoute('demo-route');

engine.on('route:waypoint-reached', () => {
    // Advance manually (e.g. on button click)
    engine.proceedToNextWaypoint();
});

// proceedToNextWaypoint / proceedToPrevWaypoint switch the route to manual
// mode automatically, so they work even if the route was started in auto mode:
engine.startCameraRoute('tour'); // auto mode
// ...later, take over manual control:
engine.proceedToNextWaypoint(); // switches to manual and advances

// POI-linked route: waypoints derive camera data from POIs
engine.setCameraRoutes([
    {
        id: 'poi-tour',
        defaultMode: 'manual',
        waypoints: [
            { poiId: 'entrance', easing: 'ease-in' },
            { target: [5, 2, 0], lookAt: [0, 0, 0], autoAdvance: true },
            { poiId: 'main-hall', duration: 3000 },
        ],
    },
]);
engine.startCameraRoute('poi-tour');

engine.on('route:waypoint-reached', ({ poiId }) => {
    if (poiId) {
        console.log(`Arrived at POI: ${poiId}`);
    }
});

// Orbit (arc) waypoints: camera arcs around a target point
engine.setCameraRoutes([
    {
        id: 'orbit-tour',
        waypoints: [
            {
                target: [0, 0, 0],
                orbit: { radius: 5, azimuth: 0, polar: Math.PI / 6 },
                lookAt: 'target',
                duration: 3000,
                easing: 'ease-in-out',
            },
            {
                target: [0, 0, 0],
                orbit: { radius: 5, azimuth: Math.PI, polar: Math.PI / 4 },
                lookAt: 'target',
                duration: 4000,
                easing: 'ease-in-out',
            },
        ],
        loop: true,
    },
]);
engine.startCameraRoute('orbit-tour');

// Waypoints with camera constraints
engine.setCameraRoutes([
    {
        id: 'constrained-tour',
        waypoints: [
            {
                target: [0, 1, 5],
                lookAt: [0, 0, 0],
                // Constraints applied during the transition to this waypoint
                transitionConstraints: {
                    rotation: { locked: true },
                },
                // Constraints applied when the waypoint is reached (stay active until overridden)
                constraints: {
                    rotation: { pitch: { min: -0.3, max: 0.3 } },
                },
            },
            {
                target: [3, 1, 3],
                lookAt: [0, 0, 0],
                constraints: null, // clear constraints at this waypoint
            },
        ],
    },
]);

// Scrub mode: external source drives camera progress
engine.setCameraRoutes([
    {
        id: 'scroll-tour',
        waypoints: [
            { poiId: 'entrance', easing: 'ease-in-out' },
            { poiId: 'main-hall', duration: 4000, easing: 'ease-in-out' }, // 2x scroll distance (longer duration = more progress range)
            { target: [10, 5, 0], lookAt: [0, 0, 0] },
            { poiId: 'exit', easing: 'ease-out' },
        ],
    },
]);

engine.startCameraRoute('scroll-tour', { mode: 'manual' });

// Map scroll position to [0, 1]
const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
window.addEventListener('scroll', () => {
    engine.setCameraRouteProgress(window.scrollY / maxScroll);
});

engine.on('route:waypoint-reached', ({ poiId, direction }) => {
    if (poiId) {
        console.log(`${direction === 'forward' ? 'Entered' : 'Left'}: ${poiId}`);
    }
});
```

### Scroll-bound routes

Instead of wiring a scroll listener manually, pass a `scroll` option to `startCameraRoute` to let the engine manage the binding:

```typescript
// Minimal — uses engine container as scroll source
engine.startCameraRoute('scroll-tour', {
    scroll: { mapping: { type: 'pixelsForFullRoute', pixels: 3000 } },
});

// Explicit element and axis
engine.startCameraRoute('scroll-tour', {
    scroll: {
        element: document.getElementById('scroll-container')!,
        axis: 'horizontal',
        mapping: { type: 'progressPerPixel', factor: 1 / 3000 },
    },
});
```

`element` defaults to the engine container. The engine attaches a **passive** `scroll` listener, reads `scrollTop` (or `scrollLeft` for horizontal), converts the offset to progress `[0, 1]`, and calls `setCameraRouteProgress` synchronously. Multiple scroll events per frame naturally coalesce into a single render because `requestRender()` is idempotent. The binding is automatically cleaned up on `stopCameraRoute()` or `destroy()`.

The `scroll` event exposes only the absolute scroll offset — both mapping modes convert that absolute offset to progress. `pixelsForFullRoute` means `progress = offset / pixels`; `progressPerPixel` means `progress = offset * factor`. Set `invert: true` to reverse direction (`progress = 1 - raw`).

## Controls

### FPS Mode (default)

- **WASD** — Move forward/backward/left/right
- **Q/E** — Move up/down
- **Mouse drag** — Look around
- **Arrow keys** — Rotate camera
- **R/F** — Roll camera
- Default movement speed is 2.0 m/s (Shift x2.5, Caps Lock x4, Ctrl x0.5)

### Orbit Mode

- **Left mouse drag** — Rotate around target
- **Right mouse drag** — Pan
- **Scroll wheel** — Zoom

## Development

```bash
# Install dependencies
npm install

# Build library
npm run build

# Type check
npm run typecheck
```

## Build Output

```
dist/
├── datum-engine.js        # ES Module
├── datum-engine.cjs       # CommonJS
└── index.d.ts             # TypeScript declarations (bundled)
```

## Peer Dependencies

- `three` >= 0.180.0
- `@sparkjsdev/spark` — [modified fork](https://gitlab.thedatum.one/datum/datum-sdk-spark-fork) (`npm:@datum-sdk/spark-fork`). Required version range is declared in `peerDependencies` of `package.json`.

## License

MIT
